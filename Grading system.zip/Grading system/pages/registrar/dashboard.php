<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Registrar') {
    header("Location: ../../login.php"); 
    exit();
}

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'trentians_gradehub';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$fullname = $_SESSION['fullname'];

// ==========================================
// FORM SUBMISSIONS LOGIC (Inuna natin ito para hindi mag-error sa headers)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'enroll') {
        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, username, password_hash, role_id, is_active, account_status) VALUES (?, ?, ?, ?, ?, 1, 1, 'Active')");
        $stmt->bind_param("sssss", $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['student_number'], password_hash('password123', PASSWORD_DEFAULT));
        if ($stmt->execute()) {
            $new_user_id = $conn->insert_id;
            $stmt2 = $conn->prepare("INSERT INTO students (user_id, student_number, course_id, year_level) VALUES (?, ?, ?, ?)");
            $stmt2->bind_param("isii", $new_user_id, $_POST['student_number'], $_POST['course_id'], $_POST['year_level']);
            $stmt2->execute();
            $_SESSION['swal_success'] = "Student enrolled successfully!"; header("Location: dashboard.php"); exit();
        }
    }
    if (isset($_POST['action']) && $_POST['action'] === 'edit') {
        $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, email=? WHERE user_id=?");
        $stmt->bind_param("sssi", $_POST['first_name'], $_POST['last_name'], $_POST['email'], $_POST['user_id']); $stmt->execute();
        $stmt2 = $conn->prepare("UPDATE students SET course_id=?, year_level=? WHERE user_id=?");
        $stmt2->bind_param("iii", $_POST['course_id'], $_POST['year_level'], $_POST['user_id']); $stmt2->execute();
        $_SESSION['swal_success'] = "Student record updated!"; header("Location: dashboard.php"); exit();
    }
    if (isset($_POST['action']) && $_POST['action'] === 'approve') {
        $conn->query("UPDATE users SET account_status = 'Active' WHERE user_id = " . $_POST['user_id']);
        $_SESSION['swal_success'] = "Account approved!"; header("Location: dashboard.php"); exit();
    }
    if (isset($_POST['action']) && $_POST['action'] === 'archive') {
        $conn->query("UPDATE users SET is_archived = 1 WHERE user_id = " . $_POST['user_id']);
        $_SESSION['swal_success'] = "Student archived!"; header("Location: dashboard.php"); exit();
    }
    if (isset($_POST['action']) && $_POST['action'] === 'assign') {
        $check = $conn->query("SELECT * FROM enrollments WHERE user_id = {$_POST['user_id']} AND subject_id = {$_POST['subject_id']}");
        if ($check->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO enrollments (user_id, subject_id, section_id) VALUES (?, ?, ?)");
            $stmt->bind_param("iii", $_POST['user_id'], $_POST['subject_id'], $_POST['section_id']); $stmt->execute();
            $_SESSION['swal_success'] = "Subject assigned!";
        } else { $_SESSION['swal_error'] = "Student already enrolled in this subject."; }
        header("Location: dashboard.php"); exit();
    }
    if (isset($_POST['action']) && $_POST['action'] === 'announce') {
        $stmt = $conn->prepare("INSERT INTO announcements (title, content, posted_by) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $_POST['title'], $_POST['content'], $fullname); $stmt->execute();
        $_SESSION['swal_success'] = "Announcement posted!"; header("Location: dashboard.php"); exit();
    }
}

// ==========================================
// FETCH DATA FOR DASHBOARD
// ==========================================
$totalStudents = $conn->query("SELECT COUNT(*) as count FROM students s JOIN users u ON s.user_id = u.user_id WHERE u.is_archived = 0")->fetch_assoc()['count'];
$pendingCount = $conn->query("SELECT COUNT(*) as count FROM users WHERE account_status = 'Pending' AND is_archived = 0")->fetch_assoc()['count'];
$studentsQuery = $conn->query("SELECT s.*, u.first_name, u.last_name, u.email, c.course_code FROM students s JOIN users u ON s.user_id = u.user_id LEFT JOIN courses c ON s.course_id = c.course_id WHERE u.is_archived = 0 ORDER BY s.student_number DESC");
$pendingUsers = $conn->query("SELECT u.*, c.course_code FROM users u JOIN roles r ON u.role_id = r.role_id LEFT JOIN students s ON s.user_id = u.user_id LEFT JOIN courses c ON s.course_id = c.course_id WHERE u.account_status = 'Pending' AND r.role_name = 'Student' AND u.is_archived = 0");
$courses = $conn->query("SELECT * FROM courses ORDER BY course_code");
$sections = $conn->query("SELECT sec.*, c.course_code FROM sections sec LEFT JOIN courses c ON sec.course_id = c.course_id");
$subjects = $conn->query("SELECT * FROM subjects");
$announcements = $conn->query("SELECT * FROM announcements ORDER BY date_posted DESC LIMIT 3");

// ==========================================
// VIEW GRADES LOGIC (Naka-embed sa loob ng layout)
// ==========================================
$isViewingGrades = isset($_GET['view_grades']);
$student = null;
$gQuery = null;

if ($isViewingGrades) {
    $student_user_id = intval($_GET['view_grades']);
    $sQuery = $conn->query("SELECT s.student_number, u.first_name, u.last_name, u.email, c.course_code, s.year_level FROM students s JOIN users u ON s.user_id = u.user_id LEFT JOIN courses c ON s.course_id = c.course_id WHERE s.user_id = $student_user_id");
    $student = $sQuery->fetch_assoc();
    
    // Naka-join na nang tama
    $gQuery = $conn->query("SELECT sub.subject_code, sub.subject_name, sec.section_name, g.grade FROM enrollments e JOIN subjects sub ON e.subject_id = sub.subject_id JOIN sections sec ON e.section_id = sec.section_id LEFT JOIN grades g ON e.enrollment_id = g.enrollment_id WHERE e.user_id = $student_user_id");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Dashboard - TRENTIANS GradeHub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100vh; overflow: hidden; max-width: 100%; }
        :root { --navy-dark: #0f2b46; --navy: #1b3a5c; --navy-light: #2d5a7a; --gold: #ffc107; --bg: #f8fafc; --border: #e2e8f0; --text: #1e293b; --text-muted: #64748b; --text-light: #94a3b8; }
        body { background: var(--bg); font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif; font-size: 14px; color: var(--text); }
        
        /* Navbar & Sidebar */
        .navbar-custom { background: linear-gradient(135deg, var(--navy-dark), var(--navy)); padding: 12px 0; border-bottom: 3px solid var(--gold); height: 70px; }
        .navbar-brand { color: white !important; font-weight: 700; font-size: 16px; display: flex; align-items: center; }
        .navbar-logo { width: 42px; height: 42px; margin-right: 12px; background: white; border-radius: 50%; padding: 3px; }
        .user-info { display: flex; align-items: center; gap: 12px; color: white; font-size: 13px; }
        .role-badge { background: var(--gold); color: var(--navy); padding: 4px 12px; border-radius: 15px; font-weight: 700; font-size: 10px; text-transform: uppercase; }
        .btn-logout { background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.2); padding: 6px 16px; border-radius: 8px; font-size: 12px; text-decoration: none; }
        
        .main-wrapper { max-width: 1400px; margin: 0 auto; padding: 24px; display: flex; gap: 20px; height: calc(100vh - 70px); overflow: hidden; }
        .sidebar { background: #ffffff; border-radius: 12px; padding: 12px 0; border: 1px solid var(--border); width: 240px; min-width: 240px; height: 100%; overflow-y: auto; }
        .sidebar .nav-item { margin: 2px 8px; }
        .sidebar .nav-link { color: #475569; padding: 10px 14px; border-radius: 8px; text-decoration: none; display: flex; align-items: center; font-size: 13px; font-weight: 500; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: linear-gradient(135deg, var(--navy), var(--navy-light)); color: white; }
        .sidebar .nav-link i { margin-right: 10px; width: 18px; }
        
        .content { flex: 1; min-width: 0; height: 100%; overflow-y: auto; padding-right: 10px; }
        .page-header h1 { font-size: 26px; font-weight: 700; color: var(--navy); margin: 0 0 4px; }
        
        /* Dashboard Specific */
        .metric-card { background: #ffffff; border: 1px solid var(--border); border-radius: 12px; padding: 20px; margin-bottom: 16px; position: relative; border-left: 4px solid var(--navy); }
        .metric-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; font-weight: 700; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: 700; color: var(--navy); line-height: 1; }
        .metric-icon { position: absolute; top: 18px; right: 18px; font-size: 28px; opacity: 0.15; }
        .metric-card.gold { border-left-color: var(--gold); }
        .panel { background: #ffffff; border: 1px solid var(--border); border-radius: 12px; margin-bottom: 20px; overflow: hidden; }
        .panel-header { padding: 16px 22px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; background: #fafbfc; }
        .panel-header h3 { font-size: 15px; font-weight: 700; color: var(--navy); margin: 0; }
        .data-table { width: 100%; margin: 0; font-size: 13px; border-collapse: collapse; }
        .data-table thead th { background: #f8fafc; font-size: 11px; text-transform: uppercase; color: var(--text-light); font-weight: 700; padding: 12px 22px; text-align: left; }
        .data-table tbody td { padding: 12px 22px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        .btn-primary-custom { background: linear-gradient(135deg, var(--navy), var(--navy-light)); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-size: 12px; font-weight: 600; text-decoration: none; }
        .btn-outline-success { color: #166534; border-color: #166534; font-size: 12px; }
        .badge-soft { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; background: #dbeafe; color: #1e40af; }
        
        /* GRADE VIEW SPECIFIC STYLES */
        .grade-document { background: white; border: 1px solid var(--border); border-radius: 12px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        .grade-header { background: linear-gradient(135deg, var(--navy-dark), var(--navy)); color: white; padding: 30px; text-align: center; position: relative; }
        .grade-header h2 { font-size: 22px; font-weight: 700; margin-bottom: 5px; }
        .grade-header p { font-size: 13px; color: rgba(255,255,255,0.7); margin: 0; }
        .student-profile-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 30px; background: #f8fafc; border-bottom: 1px solid var(--border); }
        .info-row { margin-bottom: 12px; font-size: 14px; }
        .info-row span { color: var(--text-muted); display: inline-block; width: 120px; font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
        .info-row strong { color: var(--navy); font-weight: 600; }
        .grade-table { width: 100%; border-collapse: collapse; }
        .grade-table th { background: #ffffff; font-size: 11px; text-transform: uppercase; color: var(--text-light); font-weight: 700; padding: 18px 30px; border-bottom: 2px solid var(--border); text-align: left; }
        .grade-table td { padding: 18px 30px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: middle; color: var(--text); }
        .grade-table tr:hover { background: #f8fafc; }
        .grade-badge { font-size: 14px; font-weight: 700; padding: 6px 14px; border-radius: 8px; display: inline-block; min-width: 60px; text-align: center;}
        .grade-passed { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .grade-failed { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .grade-pending { background: #f1f5f9; color: #64748b; font-size: 12px; font-weight: 600; border: 1px solid #e2e8f0; }
        
        /* Print Settings */
        @media print {
            body { background: white; overflow: visible; height: auto; }
            .sidebar, .navbar-custom, .btn, .no-print { display: none !important; }
            .main-wrapper { display: block; height: auto; padding: 0; margin: 0; }
            .content { overflow: visible; height: auto; padding: 0; }
            .grade-document { border: none; box-shadow: none; }
            .grade-header { background: white !important; color: black !important; border-bottom: 2px solid black; padding: 20px; }
            .grade-header p { color: #333 !important; }
            .student-profile-grid { background: white !important; border-bottom: 1px solid #ccc; padding: 20px 0; }
            .grade-table th { background: white !important; border-bottom: 2px solid #000; color: #000; }
            .grade-table td { border-bottom: 1px solid #ccc; }
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-custom no-print">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <img src="../../assets/images/logo.png" alt="TIFTCI" class="navbar-logo" onerror="this.style.display='none'">
                TRENTIANS GradeHub <span style="color: var(--gold); margin-left:5px;"></span>
            </a>
            <div class="ms-auto d-flex align-items-center user-info">
                <span><?php echo htmlspecialchars($fullname); ?></span>
                <span class="role-badge">REGISTRAR</span>
                <a href="../../logout.php" class="btn-logout"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
            </div>
        </div>
    </nav>

    <div class="main-wrapper">
        <!-- SIDEBAR (no-print) -->
        <aside class="sidebar no-print">
            <div class="nav-item"><a class="nav-link <?= $isViewingGrades ? '' : 'active' ?>" href="dashboard.php"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a></div>
            <div class="nav-item"><a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#enrollModal"><i class="bi bi-person-plus-fill"></i> Enroll Student</a></div>
            <div class="nav-item">
                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#approvalsModal">
                    <i class="bi bi-shield-check"></i> Approvals
                    <?php if ($pendingCount > 0): ?><span class="badge bg-danger ms-auto"><?= $pendingCount ?></span><?php endif; ?>
                </a>
            </div>
            <div class="nav-item"><a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#announceModal"><i class="bi bi-megaphone-fill"></i> Post Announcement</a></div>
        </aside>

        <main class="content">
            
            <?php if ($isViewingGrades && $student): ?>
                <!-- ========================================== -->
                <!-- PREMIUM GRADE VIEWER (Nasa loob ng Dashboard) -->
                <!-- ========================================== -->
                <div class="d-flex justify-content-between align-items-center mb-4 no-print">
                    <a href="dashboard.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i> Back to Masterlist</a>
                    <button class="btn btn-primary btn-sm" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print Record</button>
                </div>

                <div class="grade-document">
                    <!-- Document Header -->
                    <div class="grade-header">
                        <h2>TRENT INFORMATION FIRST TECHNICAL CAREER INSTITUTE</h2>
                        <p>OFFICIAL ACADEMIC RECORD</p>
                    </div>

                    <!-- Student Info -->
                    <div class="student-profile-grid">
                        <div>
                            <div class="info-row"><span>Student Name</span> <strong><?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?></strong></div>
                            <div class="info-row"><span>Student No.</span> <strong><?= htmlspecialchars($student['student_number']) ?></strong></div>
                            <div class="info-row"><span>Email Address</span> <strong><?= htmlspecialchars($student['email']) ?></strong></div>
                        </div>
                        <div>
                            <div class="info-row"><span>Strand/Course</span> <strong><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></strong></div>
                            <div class="info-row"><span>Year Level</span> <strong><?= htmlspecialchars($student['year_level']) ?> Year</strong></div>
                            <div class="info-row"><span>Generated On</span> <strong><?= date('F j, Y') ?></strong></div>
                        </div>
                    </div>

                    <!-- Grades Table -->
                    <div class="table-responsive">
                        <table class="grade-table">
                            <thead>
                                <tr>
                                    <th>Subject Code</th>
                                    <th>Descriptive Title</th>
                                    <th>Section</th>
                                    <th class="text-center">Final Grade</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($gQuery->num_rows > 0): ?>
                                    <?php while ($g = $gQuery->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong><?= htmlspecialchars($g['subject_code']) ?></strong></td>
                                        <td><?= htmlspecialchars($g['subject_name']) ?></td>
                                        <td><span class="badge-soft"><?= htmlspecialchars($g['section_name']) ?></span></td>
                                        <td class="text-center">
                                            <?php if ($g['grade'] !== null && $g['grade'] !== ''): ?>
                                                <span class="grade-badge <?= (is_numeric($g['grade']) && $g['grade'] >= 75) ? 'grade-passed' : 'grade-failed' ?>">
                                                    <?= htmlspecialchars($g['grade']) ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="grade-badge grade-pending">Not Graded</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="4" class="text-center py-5 text-muted">No subjects assigned to this student yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php else: ?>
                <!-- ========================================== -->
                <!-- MAIN DASHBOARD (Default view) -->
                <!-- ========================================== -->
                <div class="page-header">
                    <h1>Student Masterlist</h1>
                    <p>Manage and view students by year level.</p>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-lg-6">
                        <div class="metric-card">
                            <div class="metric-icon"><i class="bi bi-people-fill"></i></div>
                            <div class="metric-label">Total Active Students</div>
                            <div class="metric-value"><?= $totalStudents ?></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="metric-card gold" data-bs-toggle="modal" data-bs-target="#approvalsModal">
                            <div class="metric-icon"><i class="bi bi-shield-exclamation"></i></div>
                            <div class="metric-label">Pending Approvals</div>
                            <div class="metric-value"><?= $pendingCount ?></div>
                        </div>
                    </div>
                </div>

                <!-- ANNOUNCEMENTS SECTION -->
                <?php if ($announcements->num_rows > 0): ?>
                <div class="panel mb-4" style="border-left: 4px solid var(--gold);">
                    <div class="panel-header" style="background: #fffdf5;">
                        <h3><i class="bi bi-megaphone-fill text-warning me-2"></i> Recent Announcements</h3>
                        <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#announceModal">Post New</button>
                    </div>
                    <div class="p-3">
                        <?php while($a = $announcements->fetch_assoc()): ?>
                            <div class="mb-3 pb-3 border-bottom">
                                <h6 class="fw-bold text-primary mb-1"><?= htmlspecialchars($a['title']) ?></h6>
                                <p class="mb-1 text-muted small"><?= nl2br(htmlspecialchars($a['content'])) ?></p>
                                <small class="text-secondary" style="font-size:10px;">Posted by: <?= htmlspecialchars($a['posted_by']) ?> | <?= date('M d, Y', strtotime($a['date_posted'])) ?></small>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- MASTERLIST PANEL -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>Students List</h3>
                        <div class="d-flex gap-2">
                            <a href="?export=excel" class="btn btn-outline-success btn-sm d-flex align-items-center"><i class="bi bi-file-earmark-excel me-1"></i> Export</a>
                            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#enrollModal"><i class="bi bi-person-plus"></i> Enroll</button>
                        </div>
                    </div>

                    <div class="px-4 pt-3">
                        <ul class="nav nav-tabs custom-tabs" id="yearTabs">
                            <li class="nav-item"><button class="nav-link active" data-year="all">All Years</button></li>
                            <li class="nav-item"><button class="nav-link" data-year="1">1st Year</button></li>
                            <li class="nav-item"><button class="nav-link" data-year="2">2nd Year</button></li>
                            <li class="nav-item"><button class="nav-link" data-year="3">3rd Year</button></li>
                            <li class="nav-item"><button class="nav-link" data-year="4">4th Year</button></li>
                        </ul>
                    </div>

                    <div class="table-responsive">
                        <table class="data-table" id="masterlistTable">
                            <thead>
                                <tr>
                                    <th>Student No.</th>
                                    <th>Name</th>
                                    <th>Strand / Course</th>
                                    <th>Year Level</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($studentsQuery->num_rows > 0): ?>
                                    <?php while ($s = $studentsQuery->fetch_assoc()): ?>
                                    <tr class="student-row" data-year="<?= $s['year_level'] ?>">
                                        <td><strong style="color: var(--navy);"><?= htmlspecialchars($s['student_number']) ?></strong></td>
                                        <td>
                                            <div style="font-weight: 600; color: var(--navy);"><?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?></div>
                                            <div style="font-size: 11px; color: var(--text-light);"><?= htmlspecialchars($s['email']) ?></div>
                                        </td>
                                        <td><span class="badge-soft"><?= htmlspecialchars($s['course_code'] ?? 'N/A') ?></span></td>
                                        <td><strong><?= htmlspecialchars($s['year_level']) ?> Year</strong></td>
                                        <td class="text-end">
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">Manage</button>
                                                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                                    <li>
                                                        <button class="dropdown-item edit-btn" data-bs-toggle="modal" data-bs-target="#editStudentModal"
                                                            data-user-id="<?= $s['user_id'] ?>" data-student-number="<?= htmlspecialchars($s['student_number']) ?>"
                                                            data-first-name="<?= htmlspecialchars($s['first_name']) ?>" data-last-name="<?= htmlspecialchars($s['last_name']) ?>"
                                                            data-email="<?= htmlspecialchars($s['email']) ?>" data-course-id="<?= $s['course_id'] ?>" data-year-level="<?= $s['year_level'] ?>">
                                                            <i class="bi bi-pencil-square me-2"></i> Edit Info
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button class="dropdown-item assign-btn" data-bs-toggle="modal" data-bs-target="#assignModal" data-user-id="<?= $s['user_id'] ?>" data-student-name="<?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?>">
                                                            <i class="bi bi-journal-plus me-2"></i> Assign Subjects
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="?view_grades=<?= $s['user_id'] ?>">
                                                            <i class="bi bi-card-checklist me-2"></i> View Grades
                                                        </a>
                                                    </li>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li>
                                                        <form method="POST" class="archive-form">
                                                            <input type="hidden" name="action" value="archive">
                                                            <input type="hidden" name="user_id" value="<?= $s['user_id'] ?>">
                                                            <button type="submit" class="dropdown-item text-danger"><i class="bi bi-archive me-2"></i> Archive Student</button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center py-4 text-muted">No students found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- ========================================== -->
    <!-- MODALS (Only relevant if not printing) -->
    <!-- ========================================== -->
    <?php if (!$isViewingGrades): ?>
    <!-- Enroll Student Modal -->
    <div class="modal fade" id="enrollModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Enroll New Student</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <form method="POST">
                    <input type="hidden" name="action" value="enroll">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6"><label class="form-label">Student Number</label><input type="text" name="student_number" class="form-control" required></div>
                            <div class="col-md-6"><label class="form-label">Email Address</label><input type="email" name="email" class="form-control" required></div>
                            <div class="col-md-6"><label class="form-label">First Name</label><input type="text" name="first_name" class="form-control" required></div>
                            <div class="col-md-6"><label class="form-label">Last Name</label><input type="text" name="last_name" class="form-control" required></div>
                            <div class="col-md-6">
                                <label class="form-label">Strand / Course</label>
                                <select name="course_id" class="form-select" required>
                                    <option value="">Select...</option>
                                    <?php $courses->data_seek(0); while ($c = $courses->fetch_assoc()): ?><option value="<?= $c['course_id'] ?>"><?= $c['course_code'] ?></option><?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Year Level</label>
                                <select name="year_level" class="form-select" required>
                                    <option value="1">1st Year</option><option value="2">2nd Year</option><option value="3">3rd Year</option><option value="4">4th Year</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn-primary-custom">Save & Enroll</button></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Student Modal -->
    <div class="modal fade" id="editStudentModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Edit Student Record</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <form method="POST">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6"><label class="form-label">Student Number</label><input type="text" id="edit_student_number" class="form-control" readonly style="background:#f1f5f9;"></div>
                            <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" id="edit_email" class="form-control" required></div>
                            <div class="col-md-6"><label class="form-label">First Name</label><input type="text" name="first_name" id="edit_first_name" class="form-control" required></div>
                            <div class="col-md-6"><label class="form-label">Last Name</label><input type="text" name="last_name" id="edit_last_name" class="form-control" required></div>
                            <div class="col-md-6">
                                <label class="form-label">Strand / Course</label>
                                <select name="course_id" id="edit_course_id" class="form-select" required>
                                    <?php $courses->data_seek(0); while ($c = $courses->fetch_assoc()): ?><option value="<?= $c['course_id'] ?>"><?= $c['course_code'] ?></option><?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Year Level</label>
                                <select name="year_level" id="edit_year_level" class="form-select" required>
                                    <option value="1">1st Year</option><option value="2">2nd Year</option><option value="3">3rd Year</option><option value="4">4th Year</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn-primary-custom">Update Record</button></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Assign Subjects Modal -->
    <div class="modal fade" id="assignModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Assign Subject & Section</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <form method="POST">
                    <input type="hidden" name="action" value="assign">
                    <input type="hidden" name="user_id" id="assign_user_id">
                    <div class="modal-body">
                        <div class="alert alert-info py-2 small mb-3">Assigning to: <strong id="assign_student_name"></strong></div>
                        <div class="mb-3">
                            <label class="form-label">Select Subject</label>
                            <select name="subject_id" class="form-select" required>
                                <option value="">Select Subject...</option>
                                <?php $subjects->data_seek(0); while ($sub = $subjects->fetch_assoc()): ?>
                                    <option value="<?= $sub['subject_id'] ?>"><?= $sub['subject_code'] ?> - <?= $sub['subject_name'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Select Section</label>
                            <select name="section_id" class="form-select" required>
                                <option value="">Select Section...</option>
                                <?php $sections->data_seek(0); while ($sec = $sections->fetch_assoc()): ?>
                                    <option value="<?= $sec['section_id'] ?>"><?= $sec['section_name'] ?> (<?= $sec['course_code'] ?>)</option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn-primary-custom">Assign</button></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Post Announcement Modal -->
    <div class="modal fade" id="announceModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Post Announcement</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <form method="POST">
                    <input type="hidden" name="action" value="announce">
                    <div class="modal-body">
                        <div class="mb-3"><label class="form-label">Title</label><input type="text" name="title" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">Message</label><textarea name="content" class="form-control" rows="4" required></textarea></div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn-primary-custom">Post</button></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Approvals Modal -->
    <div class="modal fade" id="approvalsModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Pending Approvals</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body p-0">
                    <table class="data-table">
                        <thead><tr><th>Name</th><th>Email</th><th>Strand</th><th class="text-end">Action</th></tr></thead>
                        <tbody>
                            <?php if ($pendingUsers->num_rows > 0): ?>
                                <?php while ($p = $pendingUsers->fetch_assoc()): ?>
                                <tr>
                                    <td><div class="fw-bold"><?= htmlspecialchars($p['first_name'] . ' ' . $p['last_name']) ?></div><small class="text-muted">@<?= htmlspecialchars($p['username']) ?></small></td>
                                    <td><?= htmlspecialchars($p['email']) ?></td>
                                    <td><span class="badge-soft"><?= htmlspecialchars($p['course_code'] ?? 'N/A') ?></span></td>
                                    <td class="text-end">
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="approve"><input type="hidden" name="user_id" value="<?= $p['user_id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-success"><i class="bi bi-check-lg"></i> Approve</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" class="text-center py-4 text-muted">No pending accounts.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('#yearTabs .nav-link').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('#yearTabs .nav-link').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                let selectedYear = this.getAttribute('data-year');
                document.querySelectorAll('.student-row').forEach(row => {
                    row.style.display = (selectedYear === 'all' || row.getAttribute('data-year') === selectedYear) ? '' : 'none';
                });
            });
        });

        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', function() {
                document.getElementById('edit_user_id').value = this.getAttribute('data-user-id');
                document.getElementById('edit_student_number').value = this.getAttribute('data-student-number');
                document.getElementById('edit_first_name').value = this.getAttribute('data-first-name');
                document.getElementById('edit_last_name').value = this.getAttribute('data-last-name');
                document.getElementById('edit_email').value = this.getAttribute('data-email');
                document.getElementById('edit_course_id').value = this.getAttribute('data-course-id');
                document.getElementById('edit_year_level').value = this.getAttribute('data-year-level');
            });
        });

        document.querySelectorAll('.assign-btn').forEach(button => {
            button.addEventListener('click', function() {
                document.getElementById('assign_user_id').value = this.getAttribute('data-user-id');
                document.getElementById('assign_student_name').innerText = this.getAttribute('data-student-name');
            });
        });

        document.querySelectorAll('.archive-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Archive Student?', text: "This student will be removed from the active masterlist.", icon: 'warning',
                    showCancelButton: true, confirmButtonColor: '#d33', cancelButtonColor: '#3085d6', confirmButtonText: 'Yes, Archive'
                }).then((result) => { if (result.isConfirmed) this.submit(); });
            });
        });

        <?php if (isset($_SESSION['swal_success'])): ?>
            Swal.fire({ icon: 'success', title: 'Success!', text: '<?php echo $_SESSION['swal_success']; ?>', timer: 2500, showConfirmButton: false });
            <?php unset($_SESSION['swal_success']); ?>
        <?php endif; ?>
    </script>
</body>
</html>