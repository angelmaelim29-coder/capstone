<?php
session_start();
require_once 'db.php';

// Check if logged in as admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php"); 
    exit();
}

// Kunin ang totoong counts mula sa database
try {
    $users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $students_count = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
} catch (Exception $e) {
    $users_count = 1; 
    $students_count = 3; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Trentians GradeHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* EXACT COLORS FROM YOUR LOGIN PAGE */
        :root {
            --brand-navy: #102542; 
            --brand-yellow: #fbbf24;
            --bg-body: #f4f7f9;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --card-bg: #ffffff;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-body); display: flex; min-height: 100vh; color: var(--text-main); }

        /* --- SIDEBAR (Matches Login Page Left Panel) --- */
        .sidebar {
            width: 260px;
            background-color: var(--brand-navy);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 24px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-header img { width: 40px; height: 40px; border-radius: 50%; background: white; padding: 2px; border: 2px solid var(--brand-yellow); }
        .sidebar-header h2 { font-size: 1rem; font-weight: 700; letter-spacing: 0.5px; color: white; }
        
        .sidebar-menu { padding: 20px 12px; flex: 1; }
        .menu-label { font-size: 0.7rem; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px; margin: 20px 0 10px 12px; }
        
        .menu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 12px 16px; color: #cbd5e1; text-decoration: none;
            border-radius: 8px; margin-bottom: 4px; font-size: 0.9rem; font-weight: 500;
            transition: all 0.2s ease;
        }
        .menu-item:hover { background-color: rgba(255,255,255,0.05); color: white; }
        .menu-item.active { background-color: var(--brand-yellow); color: var(--brand-navy); font-weight: 700; }
        .menu-item i { width: 20px; text-align: center; font-size: 1.1rem; }

        /* --- MAIN CONTENT --- */
        .main-content { margin-left: 260px; flex: 1; display: flex; flex-direction: column; }

        /* --- TOPBAR --- */
        .topbar {
            background: white; padding: 20px 32px;
            display: flex; justify-content: space-between; align-items: center;
            border-bottom: 1px solid var(--border-color);
            position: sticky; top: 0; z-index: 10;
        }
        .page-title h1 { font-size: 1.4rem; font-weight: 700; color: var(--brand-navy); }
        .page-title p { font-size: 0.85rem; color: var(--text-muted); margin-top: 4px; }
        
        .topbar-right { display: flex; align-items: center; gap: 20px; }
        .user-profile { display: flex; align-items: center; gap: 12px; }
        .user-info { text-align: right; }
        .user-info h4 { font-size: 0.9rem; font-weight: 600; color: var(--brand-navy); }
        .user-info p { font-size: 0.75rem; color: var(--text-muted); }
        .user-avatar { width: 40px; height: 40px; background: var(--brand-navy); color: var(--brand-yellow); border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: 700; font-size: 1.1rem; }
        
        .btn-logout { color: var(--text-muted); text-decoration: none; font-size: 1.1rem; transition: color 0.2s; margin-left: 10px;}
        .btn-logout:hover { color: #ef4444; }

        /* --- DASHBOARD BODY --- */
        .dashboard-body { padding: 32px; max-width: 1400px; margin: 0 auto; width: 100%; }

        /* --- STATS CARDS --- */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 24px; margin-bottom: 32px; }
        
        .stat-card {
            background: var(--card-bg); padding: 24px; border-radius: 12px;
            border: 1px solid var(--border-color); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
            display: flex; justify-content: space-between; align-items: flex-start;
            transition: transform 0.2s ease;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05); }
        
        .stat-info h3 { font-size: 0.85rem; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-info h2 { font-size: 2rem; font-weight: 700; color: var(--brand-navy); line-height: 1; }
        
        /* Elegant Icon Wrapper matching the theme */
        .stat-icon {
            width: 50px; height: 50px; border-radius: 12px;
            display: flex; justify-content: center; align-items: center; font-size: 1.4rem;
            background: rgba(16, 37, 66, 0.05); color: var(--brand-navy);
        }
        .stat-card:hover .stat-icon { background: var(--brand-yellow); color: var(--brand-navy); transition: 0.3s; }

        /* --- QUICK ACTIONS --- */
        .section-title { font-size: 1.2rem; font-weight: 700; color: var(--brand-navy); margin-bottom: 16px; }
        
        .quick-actions {
            background: var(--card-bg); padding: 24px; border-radius: 12px;
            border: 1px solid var(--border-color); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
        }
        .action-buttons { display: flex; gap: 16px; flex-wrap: wrap; }
        
        .btn-action {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 12px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 600;
            text-decoration: none; cursor: pointer; transition: all 0.2s ease;
            background: white; border: 1px solid var(--border-color); color: var(--brand-navy);
        }
        .btn-action:hover { background: #f8fafc; border-color: #cbd5e1; }
        
        .btn-action-primary { background: var(--brand-navy); border: 1px solid var(--brand-navy); color: white; }
        .btn-action-primary:hover { background: #081526; border-color: #081526; color: var(--brand-yellow); }
        
        .btn-action-accent { background: var(--brand-yellow); border: 1px solid var(--brand-yellow); color: var(--brand-navy); }
        .btn-action-accent:hover { background: #eab308; border-color: #eab308; }

        .btn-action i { font-size: 1rem; }

    </style>
</head>
<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="assets/images/logo.png" alt="TIFTCI Logo">
            <h2>TIFTCI Admin</h2>
        </div>
        
        <div class="sidebar-menu">
            <div class="menu-label">Main Menu</div>
            <a href="admin_dashboard.php" class="menu-item active"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
            
            <div class="menu-label">Management</div>
            <a href="#" class="menu-item"><i class="fa-solid fa-users"></i> Students</a>
            <a href="#" class="menu-item"><i class="fa-solid fa-chalkboard-user"></i> Faculty</a>
            <a href="#" class="menu-item"><i class="fa-solid fa-book"></i> Courses</a>
            
            <div class="menu-label">System</div>
            <a href="#" class="menu-item"><i class="fa-solid fa-gear"></i> Settings</a>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        
        <!-- TOPBAR -->
        <div class="topbar">
            <div class="page-title">
                <h1>Dashboard Overview</h1>
                <p>Welcome back, <?php echo $_SESSION['full_name']; ?>. Here is your summary.</p>
            </div>
            
            <div class="topbar-right">
                <div class="user-profile">
                    <div class="user-info">
                        <h4><?php echo $_SESSION['full_name']; ?></h4>
                        <p>System Administrator</p>
                    </div>
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
                    </div>
                </div>
                <a href="logout.php" class="btn-logout" title="Logout"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
            </div>
        </div>

        <!-- BODY -->
        <div class="dashboard-body">
            
            <!-- STATS GRID -->
            <div class="stats-grid">
                
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Total Users</h3>
                        <h2><?php echo $users_count; ?></h2>
                    </div>
                    <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
                </div>

                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Registered Students</h3>
                        <h2><?php echo $students_count; ?></h2>
                    </div>
                    <div class="stat-icon"><i class="fa-solid fa-user-graduate"></i></div>
                </div>

                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Active Faculty</h3>
                        <h2>3</h2>
                    </div>
                    <div class="stat-icon"><i class="fa-solid fa-chalkboard-user"></i></div>
                </div>

                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Active Courses</h3>
                        <h2>3</h2>
                    </div>
                    <div class="stat-icon"><i class="fa-solid fa-book"></i></div>
                </div>

            </div>

            <!-- QUICK ACTIONS SECTION -->
            <div class="section-title">Quick Actions</div>
            <div class="quick-actions">
                <div class="action-buttons">
                    
                    <!-- Premium Buttons -->
                    <a href="add_student.php" class="btn-action btn-action-accent">
                        <i class="fa-solid fa-plus"></i> Add New Student
                    </a>
                    
                    <a href="#" class="btn-action btn-action-primary">
                        <i class="fa-solid fa-user-plus"></i> Enroll Faculty
                    </a>
                    
                    <a href="#" class="btn-action">
                        <i class="fa-solid fa-book-medical"></i> Create Course
                    </a>

                </div>
            </div>

        </div>
    </div>

</body>
</html>