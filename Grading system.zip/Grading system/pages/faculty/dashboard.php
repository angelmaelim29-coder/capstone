<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Faculty') { header('Location: ../../login.php'); exit(); }

$host = 'localhost'; $user = 'root'; $pass = ''; $dbname = 'trentians_gradehub';
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$fullname = $_SESSION['fullname']; 
$email = "faculty@tiftci.edu.ph"; 

// ==========================================
// LOGIC PARA SA INLINE SAVE & SUBMIT
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'save_inline') {
        $enrollment_id = intval($_POST['enrollment_id']);
        $prelim = $_POST['prelim'];
        $midterm = $_POST['midterm'];
        $prefinal = $_POST['prefinal'];
        $final = $_POST['final'];
        $comment = $_POST['comment'];
        
        $check = $conn->query("SELECT grade_id FROM grades WHERE enrollment_id = $enrollment_id");
        if ($check->num_rows > 0) {
            $conn->query("UPDATE grades SET prelim_grade='$prelim', midterm_grade='$midterm', prefinal_grade='$prefinal', final_grade='$final', teacher_comment='$comment' WHERE enrollment_id=$enrollment_id");
        } else {
            $conn->query("INSERT INTO grades (enrollment_id, prelim_grade, midterm_grade, prefinal_grade, final_grade, teacher_comment) VALUES ($enrollment_id, '$prelim', '$midterm', '$prefinal', '$final', '$comment')");
        }
        $_SESSION['swal_success'] = "Grade updated for student!";
        header("Location: dashboard.php?view_class={$_POST['section_id']}&subject={$_POST['subject_id']}");
        exit();
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'submit_class') {
        $section_id = intval($_POST['section_id']);
        $subject_id = intval($_POST['subject_id']);
        $conn->query("UPDATE grades g JOIN enrollments e ON g.enrollment_id = e.enrollment_id SET g.status = 'Submitted' WHERE e.section_id = $section_id AND e.subject_id = $subject_id");
        $_SESSION['swal_success'] = "Grades successfully submitted to the Registrar!";
        header("Location: dashboard.php");
        exit();
    }
}

// ==========================================
// FETCH CLASSES
// ==========================================
$classes = $conn->query("
    SELECT DISTINCT sec.section_id, sec.section_name as section_code, sec.section_name,
        sub.subject_id, sub.subject_code, sub.subject_name, 3 as units,
        (SELECT COUNT(*) FROM enrollments e WHERE e.section_id = sec.section_id AND e.subject_id = sub.subject_id) as student_count
    FROM sections sec
    JOIN subjects sub ON sub.course_id = sec.course_id
    GROUP BY sec.section_id, sub.subject_id
    ORDER BY sec.section_name, sub.subject_code
");
$classesList = [];
while ($classes && $c = $classes->fetch_assoc()) { $classesList[] = $c; }

$totalClasses = count($classesList); 
$totalStudents = 0; 
foreach ($classesList as $c) { $totalStudents += ($c['student_count'] ?? 0); }

// ==========================================
// FETCH STUDENTS FOR SPECIFIC CLASS
// ==========================================
$isViewingClass = isset($_GET['view_class']) && isset($_GET['subject']);
$classInfo = null;
$studentsList = [];
$isSubmitted = false;
$gradedCount = 0;

if ($isViewingClass) {
    $sec_id = intval($_GET['view_class']);
    $sub_id = intval($_GET['subject']);
    
    $infoQ = $conn->query("SELECT sec.section_name, sub.subject_code, sub.subject_name FROM sections sec, subjects sub WHERE sec.section_id = $sec_id AND sub.subject_id = $sub_id");
    $classInfo = $infoQ->fetch_assoc();
    
    $studentsQuery = $conn->query("
        SELECT e.enrollment_id, s.student_number, u.first_name, u.last_name, u.email, c.course_code, s.year_level,
               g.grade_id, g.prelim_grade, g.midterm_grade, g.prefinal_grade, g.final_grade, g.teacher_comment, g.status
        FROM enrollments e
        JOIN users u ON e.user_id = u.user_id
        JOIN students s ON e.user_id = s.user_id
        LEFT JOIN courses c ON s.course_id = c.course_id
        LEFT JOIN grades g ON e.enrollment_id = g.enrollment_id
        WHERE e.section_id = $sec_id AND e.subject_id = $sub_id
        ORDER BY u.last_name ASC
    ");
    
    if($studentsQuery) {
        while($row = $studentsQuery->fetch_assoc()) {
            $studentsList[] = $row;
            if ($row['status'] === 'Submitted') { $isSubmitted = true; }
            if (!empty($row['final_grade'])) { $gradedCount++; }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Faculty Dashboard - TRENTIANS GradeHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100vh;overflow:hidden;max-width:100%}
:root{--navy-dark:#0f2b46;--navy:#1b3a5c;--navy-light:#2d5a7a;--gold:#ffc107;--bg:#f8fafc;--border:#e2e8f0;--text:#1e293b;--text-muted:#64748b;--text-light:#94a3b8}
body{background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,'Inter','Segoe UI',sans-serif;font-size:14px;color:var(--text)}

/* NAVBAR */
.navbar-custom{background:linear-gradient(135deg,var(--navy-dark),var(--navy));padding:12px 0;box-shadow:0 2px 12px rgba(15,43,70,.25);border-bottom:3px solid var(--gold);height:70px;position:relative;z-index:100}
.navbar-custom .container{max-width:1400px}
.navbar-brand{color:#fff!important;font-weight:700;font-size:16px;display:flex;align-items:center}
.navbar-logo{width:42px;height:42px;margin-right:12px;background:#fff;border-radius:50%;padding:3px}
.user-info{display:flex;align-items:center;gap:12px;font-size:13px;color:rgba(255,255,255,.9)}
.role-badge{background:var(--gold);color:var(--navy);padding:4px 12px;border-radius:15px;font-weight:700;font-size:10px;text-transform:uppercase}
.btn-logout{background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.2);padding:6px 16px;border-radius:8px;font-size:12px;text-decoration:none}
.nav-avatar-initials{width:38px;height:38px;border-radius:50%;background:var(--gold);color:var(--navy);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;border:2px solid var(--gold)}

/* MAIN WRAPPER */
.main-wrapper{max-width:1400px;margin:0 auto;padding:24px;display:flex;gap:20px;height:calc(100vh - 70px);overflow:hidden}

/* SIDEBAR */
.sidebar{background:#fff;border-radius:12px;padding:12px 0;border:1px solid var(--border);width:240px;min-width:240px;height:100%;overflow-y:auto}
.sidebar .nav-item{margin:2px 8px}
.sidebar .nav-link{color:#475569;padding:10px 14px;border-radius:8px;text-decoration:none;display:flex;align-items:center;font-size:13px;font-weight:500}
.sidebar .nav-link:hover, .sidebar .nav-link.active{background:linear-gradient(135deg,var(--navy),var(--navy-light));color:#fff}
.sidebar .nav-link i{margin-right:10px;width:18px;font-size:15px;color:var(--text-muted)}
.sidebar .nav-link.active i{color:var(--gold)}

/* CONTENT */
.content{flex:1;min-width:0;height:100%;overflow-y:auto;padding-right:10px}
.page-header{margin-bottom:24px}
.page-header h1{font-size:26px;font-weight:700;color:var(--navy);margin:0 0 4px}
.page-header p{color:var(--text-muted);font-size:13px;margin:0}

/* METRIC CARDS */
.metric-card{background:#fff;border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;position:relative;border-left:4px solid var(--navy);transition:all .2s}
.metric-card:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(27,58,92,.1);border-left-color:var(--gold)}
.metric-label{font-size:11px;color:var(--text-muted);text-transform:uppercase;font-weight:700;margin-bottom:8px}
.metric-value{font-size:32px;font-weight:700;color:var(--navy);line-height:1}
.metric-icon{position:absolute;top:18px;right:18px;font-size:28px;opacity:.15}
.metric-card.green{border-left-color:#10b981}
.metric-card.gold{border-left-color:var(--gold)}
.metric-card.teal{border-left-color:#14b8a6}

/* PANELS & TABLES */
.panel{background:#fff;border:1px solid var(--border);border-radius:12px;margin-bottom:20px;overflow:hidden}
.panel-header{padding:16px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:#fafbfc}
.panel-header h3{font-size:15px;font-weight:700;color:var(--navy);margin:0;display:flex;align-items:center;gap:8px}

.data-table{width:100%;margin:0;font-size:13px;border-collapse:collapse}
.data-table thead th{background:#f8fafc;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--text-light);font-weight:700;padding:15px 20px;border-bottom:2px solid var(--border);text-align:left; position: sticky; top: 0; z-index: 10;}
.data-table tbody td{padding:12px 20px;vertical-align:middle;border-bottom:1px solid #f1f5f9;color:var(--text)}
.data-table tbody tr:hover{background:#f8fafc;}

/* BUTTONS */
.btn-primary-custom{background:linear-gradient(135deg,var(--navy),var(--navy-light));color:#fff;border:none;padding:9px 18px;border-radius:8px;font-size:12px;font-weight:600;text-decoration:none;cursor:pointer}
.btn-primary-custom:hover{background:linear-gradient(135deg,var(--navy-dark),var(--navy));color:var(--gold)}
.btn-upload{background:linear-gradient(135deg,#10b981,#34d399);color:#fff;border:none;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:600;display:inline-flex;align-items:center;gap:5px;cursor:pointer;text-decoration:none;}
.btn-upload:hover{background:linear-gradient(135deg,#059669,#10b981);color:#fff}
.btn-submit{background:linear-gradient(135deg,#ef4444,#f87171);color:#fff;border:none;padding:10px 20px;border-radius:8px;font-size:14px;font-weight:700;display:inline-flex;align-items:center;gap:8px;cursor:pointer;box-shadow:0 4px 12px rgba(239,68,68,0.3);}
.btn-submit:hover{background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff}

/* INLINE GRADING INPUTS (Excel-style) */
.grade-input{width: 70px; text-align: center; font-weight: 600; font-size: 13px; border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px; background: #fff; color: var(--navy);}
.grade-input:focus{border-color: var(--navy); outline: none; box-shadow: 0 0 0 3px rgba(27,58,92,.15);}
.grade-input:disabled {background: #f1f5f9; color: #94a3b8; cursor: not-allowed;}
.comment-input{width: 100%; border: 1px solid #cbd5e1; border-radius: 4px; padding: 6px 10px; font-size: 12px; color: var(--text);}
.comment-input:focus{border-color: var(--navy); outline: none;}
.btn-save-inline{background: var(--navy); color: white; border: none; border-radius: 4px; padding: 6px 14px; font-size: 12px; font-weight: 600; cursor: pointer;}
.btn-save-inline:hover{background: var(--navy-dark); color: var(--gold);}

/* EMPTY STATE (Kapag walang estudyante) */
.empty-state { padding: 60px 20px; text-align: center; background: #fff;}
.empty-state-icon { width: 80px; height: 80px; background: #f1f5f9; color: #94a3b8; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 36px; margin-bottom: 20px; }
.empty-state h4 { font-size: 18px; font-weight: 700; color: var(--navy); margin-bottom: 8px; }
.empty-state p { font-size: 14px; color: var(--text-muted); margin-bottom: 20px; }

.badge-soft{padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;display:inline-flex;align-items:center;gap:4px}
.badge-draft{background:#f1f5f9;color:#475569}
.badge-submitted{background:#dcfce7;color:#166534}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">
            <img src="../../assets/images/logo.png" alt="TIFTCI" class="navbar-logo" onerror="this.style.display='none'">
            TRENTIANS GradeHub <span style="color: var(--gold);">Faculty</span>
        </a>
        <div class="ms-auto d-flex align-items-center user-info">
            <div class="nav-avatar-initials"><?php echo strtoupper(substr($fullname,0,2)); ?></div>
            <span><?php echo htmlspecialchars($fullname); ?></span>
            <span class="role-badge">FACULTY</span>
            <a href="../../logout.php" class="btn-logout"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
        </div>
    </div>
</nav>

<div class="main-wrapper">
    <aside class="sidebar">
        <div class="nav-item"><a class="nav-link <?= $isViewingClass ? '' : 'active' ?>" href="dashboard.php"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a></div>
        <div class="nav-item"><a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#bulkModal"><i class="bi bi-cloud-upload-fill text-success"></i> Upload Grades (CSV)</a></div>
    </aside>

    <main class="content">
        <?php if ($isViewingClass && $classInfo): ?>
            <!-- ========================================== -->
            <!-- CLASS RECORD VIEW -->
            <!-- ========================================== -->
            <div class="d-flex justify-content-between align-items-start mb-4">
                <div>
                    <a href="dashboard.php" class="btn btn-sm btn-outline-secondary mb-3"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
                    <h1 style="font-size:26px; font-weight:700; color:var(--navy); margin:0;">
                        <?= htmlspecialchars($classInfo['section_name']) ?> - <?= htmlspecialchars($classInfo['subject_code']) ?>
                    </h1>
                    <p class="text-muted mb-0"><?= htmlspecialchars($classInfo['subject_name']) ?></p>
                </div>
                
                <?php if (!$isSubmitted && count($studentsList) > 0): ?>
                <form method="POST">
                    <input type="hidden" name="action" value="submit_class">
                    <input type="hidden" name="section_id" value="<?= $sec_id ?>">
                    <input type="hidden" name="subject_id" value="<?= $sub_id ?>">
                    <button type="submit" class="btn-submit" onclick="return confirm('Are you sure you want to submit? You cannot edit grades after submitting.')">
                        <i class="bi bi-send-check-fill"></i> Submit Grades to Registrar
                    </button>
                </form>
                <?php elseif ($isSubmitted): ?>
                    <div class="alert alert-success py-2 mb-0 shadow-sm border-0"><i class="bi bi-check-circle-fill"></i> Grades Submitted & Locked</div>
                <?php endif; ?>
            </div>

            <!-- Mini Stats para sa Class -->
            <?php if (count($studentsList) > 0): ?>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="metric-card" style="margin-bottom:0;">
                        <div class="metric-label">Total Students</div>
                        <div class="metric-value"><?= count($studentsList) ?></div>
                        <i class="bi bi-people-fill metric-icon"></i>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="metric-card green" style="margin-bottom:0;">
                        <div class="metric-label">Graded</div>
                        <div class="metric-value"><?= $gradedCount ?></div>
                        <i class="bi bi-journal-check metric-icon"></i>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="metric-card gold" style="margin-bottom:0;">
                        <div class="metric-label">Status</div>
                        <div class="metric-value" style="font-size: 1.2rem; margin-top: 10px;">
                            <?php if($isSubmitted): ?>
                                <span class="badge-soft badge-submitted"><i class="bi bi-lock-fill"></i> Locked</span>
                            <?php else: ?>
                                <span class="badge-soft badge-draft"><i class="bi bi-pencil-fill"></i> Editing</span>
                            <?php endif; ?>
                        </div>
                        <i class="bi bi-info-circle-fill metric-icon"></i>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="panel">
                <div class="panel-header">
                    <h3>Student Grade Sheet</h3>
                </div>
                <div class="table-responsive">
                    <?php if (count($studentsList) === 0): ?>
                        <!-- PROFESSIONAL EMPTY STATE -->
                        <div class="empty-state">
                            <div class="empty-state-icon"><i class="bi bi-person-x-fill"></i></div>
                            <h4>No Students Enrolled Yet</h4>
                            <p>There are currently no students assigned to this class section.<br>Please coordinate with the Registrar to enroll students.</p>
                            <a href="dashboard.php" class="btn-primary-custom">Return to Dashboard</a>
                        </div>
                    <?php else: ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th style="width: 25%;">Student</th>
                                    <th class="text-center">Prelim</th>
                                    <th class="text-center">Midterm</th>
                                    <th class="text-center">Prefinal</th>
                                    <th class="text-center">Final</th>
                                    <th style="width: 25%;">Comment</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($studentsList as $s): ?>
                                <tr>
                                    <td>
                                        <div style="font-weight:600; color:var(--navy); cursor:pointer;" 
                                             data-bs-toggle="modal" data-bs-target="#studentProfileModal"
                                             data-name="<?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?>"
                                             data-num="<?= htmlspecialchars($s['student_number']) ?>"
                                             data-email="<?= htmlspecialchars($s['email']) ?>"
                                             data-course="<?= htmlspecialchars($s['course_code'] ?? 'N/A') ?>"
                                             data-year="<?= htmlspecialchars($s['year_level']) ?>">
                                            <?= htmlspecialchars($s['first_name'] . ' ' . $s['last_name']) ?>
                                        </div>
                                        <div style="font-size:11px; color:var(--text-muted);"><?= htmlspecialchars($s['student_number']) ?></div>
                                    </td>
                                    
                                    <form method="POST">
                                        <input type="hidden" name="action" value="save_inline">
                                        <input type="hidden" name="enrollment_id" value="<?= $s['enrollment_id'] ?>">
                                        <input type="hidden" name="section_id" value="<?= $sec_id ?>">
                                        <input type="hidden" name="subject_id" value="<?= $sub_id ?>">
                                        
                                        <td class="text-center"><input type="text" name="prelim" class="grade-input" value="<?= htmlspecialchars($s['prelim_grade'] ?? '') ?>" <?= $isSubmitted ? 'disabled' : '' ?> maxlength="5" placeholder="--"></td>
                                        <td class="text-center"><input type="text" name="midterm" class="grade-input" value="<?= htmlspecialchars($s['midterm_grade'] ?? '') ?>" <?= $isSubmitted ? 'disabled' : '' ?> maxlength="5" placeholder="--"></td>
                                        <td class="text-center"><input type="text" name="prefinal" class="grade-input" value="<?= htmlspecialchars($s['prefinal_grade'] ?? '') ?>" <?= $isSubmitted ? 'disabled' : '' ?> maxlength="5" placeholder="--"></td>
                                        <td class="text-center"><input type="text" name="final" class="grade-input" value="<?= htmlspecialchars($s['final_grade'] ?? '') ?>" <?= $isSubmitted ? 'disabled' : '' ?> maxlength="5" placeholder="--"></td>
                                        <td><input type="text" name="comment" class="comment-input" value="<?= htmlspecialchars($s['teacher_comment'] ?? '') ?>" <?= $isSubmitted ? 'readonly' : '' ?> placeholder="Optional remark..."></td>
                                        
                                        <td class="text-end">
                                            <?php if (!$isSubmitted): ?>
                                                <button type="submit" class="btn-save-inline"><i class="bi bi-save"></i> Save</button>
                                            <?php else: ?>
                                                <i class="bi bi-lock-fill text-muted fs-5"></i>
                                            <?php endif; ?>
                                        </td>
                                    </form>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

        <?php else: ?>
            <!-- ========================================== -->
            <!-- MAIN DASHBOARD VIEW -->
            <!-- ========================================== -->
            <div class="page-header">
                <h1>Welcome, <?php echo htmlspecialchars($fullname); ?></h1>
                <p>Manage your classes and upload grades using the Excel template.</p>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-lg-4"><div class="metric-card"><div class="metric-icon"><i class="bi bi-book-fill"></i></div><div class="metric-label">My Classes</div><div class="metric-value"><?php echo $totalClasses; ?></div></div></div>
                <div class="col-lg-4"><div class="metric-card green"><div class="metric-icon"><i class="bi bi-people-fill"></i></div><div class="metric-label">Total Students</div><div class="metric-value"><?php echo $totalStudents; ?></div></div></div>
                <div class="col-lg-4"><div class="metric-card gold"><div class="metric-icon"><i class="bi bi-clock-history"></i></div><div class="metric-label">Pending Uploads</div><div class="metric-value">0</div></div></div>
            </div>

            <div class="panel">
                <div class="panel-header">
                    <h3>My Classes</h3>
                </div>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Section</th>
                                <th>Subject</th>
                                <th style="text-align:center;">Units</th>
                                <th style="text-align:center;">Students</th>
                                <th style="text-align:right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($classesList as $c): ?>
                        <tr>
                            <td><strong style="color:var(--navy);"><?php echo htmlspecialchars($c['section_code'] ?? 'N/A'); ?></strong></td>
                            <td>
                                <strong><?php echo htmlspecialchars($c['subject_code'] ?? 'N/A'); ?></strong>
                                <div style="font-size:11px;color:var(--text-light);margin-top:2px;"><?php echo htmlspecialchars($c['subject_name'] ?? ''); ?></div>
                            </td>
                            <td style="text-align:center;"><?php echo $c['units'] ?? 0; ?></td>
                            <td style="text-align:center;"><span class="badge bg-secondary rounded-pill"><?php echo $c['student_count'] ?? 0; ?></span></td>
                            <td style="text-align:right;">
                                <div style="display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap;">
                                    <a href="?view_class=<?= $c['section_id'] ?>&subject=<?= $c['subject_id'] ?>" class="btn btn-sm btn-outline-primary d-flex align-items-center gap-1 fw-bold">
                                        <i class="bi bi-journal-text"></i> Open Gradebook
                                    </a>
                                    <button class="btn-upload upload-grades-btn" data-section="<?php echo $c['section_id']; ?>" data-subject="<?php echo $c['subject_id']; ?>">
                                        <i class="bi bi-cloud-upload"></i> Upload
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </main>
</div>

<!-- STUDENT PROFILE MODAL -->
<div class="modal fade" id="studentProfileModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header" style="background:var(--navy); color:white;">
                <h5 class="modal-title"><i class="bi bi-person-circle me-2"></i> Student Profile</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center p-4">
                <div style="width:80px; height:80px; background:#dbeafe; color:#1e40af; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-size:2rem; font-weight:700; margin-bottom:15px;" id="prof_initial"></div>
                <h4 id="prof_name" class="fw-bold text-primary mb-1"></h4>
                <p class="text-muted small mb-4" id="prof_num"></p>
                
                <div class="text-start bg-light p-3 rounded border">
                    <div class="mb-2"><i class="bi bi-envelope-fill text-muted me-2"></i> <span id="prof_email"></span></div>
                    <div class="mb-2"><i class="bi bi-book-fill text-muted me-2"></i> <span id="prof_course"></span></div>
                    <div><i class="bi bi-layers-fill text-muted me-2"></i> <span id="prof_year"></span></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- BULK UPLOAD MODAL -->
<div class="modal fade" id="bulkModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header" style="background:var(--navy); color:white;">
                <h5 class="modal-title"><i class="bi bi-cloud-upload me-2"></i> Upload Grades via Excel</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Step 1: Select Class</label>
                    <select id="bulkClassSelect" class="form-select" onchange="updateBulkFields()">
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classesList as $c): ?>
                            <option value="<?php echo $c['section_id'].'|'.$c['subject_id']; ?>">
                                <?php echo htmlspecialchars(($c['section_code'] ?? '').' - '.($c['subject_code'] ?? '')); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">Step 2: Download Template</label>
                    <div>
                        <button type="button" class="btn-primary-custom" onclick="handleDownload()">
                            <i class="bi bi-download"></i> Download Excel Template
                        </button>
                    </div>
                </div>
                <hr>
                <form method="POST" action="../../api/faculty/bulk_upload.php" enctype="multipart/form-data">
                    <input type="hidden" name="section_id" id="bulkSectionId">
                    <input type="hidden" name="subject_id" id="bulkSubjectId">
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-muted">Step 3: Upload CSV File</label>
                        <input type="file" name="file" class="form-control" accept=".csv" required>
                        <small class="text-muted">Only CSV files. Save Excel as CSV (Comma delimited).</small>
                    </div>
                    <button type="submit" class="btn-primary-custom w-100 py-2">
                        <i class="bi bi-cloud-upload"></i> Upload & Import Grades
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.upload-grades-btn').forEach(btn => btn.addEventListener('click', function(){
    const select = document.getElementById('bulkClassSelect');
    const val = this.dataset.section + '|' + this.dataset.subject;
    for (let i = 0; i < select.options.length; i++) {
        if (select.options[i].value === val) { select.selectedIndex = i; break; }
    }
    updateBulkFields();
    new bootstrap.Modal(document.getElementById('bulkModal')).show();
}));

function updateBulkFields() {
    const s = document.getElementById('bulkClassSelect');
    if (s.value) {
        const p = s.value.split('|');
        document.getElementById('bulkSectionId').value = p[0];
        document.getElementById('bulkSubjectId').value = p[1];
    }
}

function handleDownload() {
    const s = document.getElementById('bulkClassSelect');
    if (!s.value) { alert('Please select a class first.'); return; }
    const p = s.value.split('|');
    window.location.href = '../../api/faculty/download_template.php?section=' + p[0] + '&subject=' + p[1];
}

const profileModal = document.getElementById('studentProfileModal');
if(profileModal) {
    profileModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        document.getElementById('prof_name').innerText = button.getAttribute('data-name');
        document.getElementById('prof_num').innerText = button.getAttribute('data-num');
        document.getElementById('prof_email').innerText = button.getAttribute('data-email');
        document.getElementById('prof_course').innerText = button.getAttribute('data-course');
        document.getElementById('prof_year').innerText = button.getAttribute('data-year') + ' Year Level';
        
        const name = button.getAttribute('data-name');
        document.getElementById('prof_initial').innerText = name.substring(0, 2).toUpperCase();
    });
}

<?php if (isset($_SESSION['swal_success'])): ?>
    Swal.fire({ icon: 'success', title: 'Success!', text: '<?php echo $_SESSION['swal_success']; ?>', timer: 2500, showConfirmButton: false });
    <?php unset($_SESSION['swal_success']); ?>
<?php endif; ?>
</script>
</body>
</html>